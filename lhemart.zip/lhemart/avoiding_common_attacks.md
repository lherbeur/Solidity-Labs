# Avoiding common attacks
==========================

a. The major pattern of giving specific rights to perform specific actions to only certain addresses helps to ensure that only authorized entities can perform certain operations.
b. There is a fallback function, that throws avoiding ether from being sent accidentally to the contract. 




