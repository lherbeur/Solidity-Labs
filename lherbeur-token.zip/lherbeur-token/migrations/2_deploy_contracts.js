//var ERC20 = artifacts.require("./ERC20.sol");
//var SafeMath = artifacts.require("./SafeMath.sol");
var LherbeurToken = artifacts.require("./LherbeurToken.sol");
var Voting = artifacts.require("./Voting.sol");

module.exports = function(deployer) {
  //deployer.deploy(ERC20);
  //deployer.deploy(SafeMath);
 // deployer.link(ERC20, LherbeurToken);
  //deployer.link(SafeMath, LherbeurToken);
  
  deployer.deploy(LherbeurToken);
  deployer.deploy(Voting);
};
